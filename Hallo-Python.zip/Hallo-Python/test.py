a = """
     pppp    y     y   ttttttt   h   h    oooo   nnnn          
    p   p    y   y       t      h   h   o    o  n   n
    p   p     y y        t      h   h   o    o  n   n
    pppp       y         t      hhhhh   o    o  n   n
    p          y         t      h   h   o    o  n   n
    p          y         t      h   h   o    o  n   n
    p          y         t      h   h    oooo   n   n
    """
print ('vito kroon + 99060331')

print (a) 