print ('hallo world') # output from terminal
name = input ('what s your name?') #input from terminal
print ('hallo + name')
age = input ('how old are you?')
print ('wow thats amazing,' = age)