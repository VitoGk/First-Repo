print ('Hello wereld van… ')                               
                                   
 print  ('pppp    y     y   ttttttt   h   h    oooo   nnnn          
 print   ('p   p    y   y       t      h   h   o    o  n   n')
 print   ('p   p     y y        t      h   h   o    o  n   n')
 print   ('pppp       y         t      hhhhh   o    o  n   n')
 print   ('p          y    print     t      h   h   o    o  n   n')
 print   ('p          y         t      h   h   o    o  n   n')
 print   ('p          y         t      h   h    oooo   n   n')
    print ('Vito Kroon + 99060331')